{
	EmitSoundOn("Minigun.SpinDown", self);
}