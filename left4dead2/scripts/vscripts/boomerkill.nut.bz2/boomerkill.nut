{
	EmitSoundOn("BoomerZombie.PainShort", self);
}