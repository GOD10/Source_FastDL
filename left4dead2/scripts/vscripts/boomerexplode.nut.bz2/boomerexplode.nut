{
	EmitSoundOn("BoomerZombie.Detonate", self);
}