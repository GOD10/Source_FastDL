{
	EmitSoundOn("BoomerZombie.Groan", self);
}