{
	EmitSoundOn("Minigun.SpinUp", self);
}