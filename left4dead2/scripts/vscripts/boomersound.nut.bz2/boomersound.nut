{
	EmitSoundOn("BoomerZombie.Alert", self);
}