{
	EmitSoundOn("Minigun.Fire", self);
}