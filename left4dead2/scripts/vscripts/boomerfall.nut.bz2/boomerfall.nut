{
	EmitSoundOn("BoomerZombie.Fall", self);
}